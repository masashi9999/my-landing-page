# My Landing Page (React + Tailwind)

Ready to deploy on Vercel by drag & drop.

## Scripts (optional for local dev)
- `npm install`
- `npm start`
- `npm run build`
