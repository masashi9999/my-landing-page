import React from "react";
import LandingPage from "./LandingPage";
export default function App() {
  return <LandingPage />;
}
